EV Comparison Assistant — India Edition (v1.2.0)

CONTENTS
- manifest.json: Chrome Manifest V3 extension definition
- popup.html / styles.css / popup.js: working popup and comparison UI
- dataset.json: 51 car listings and 37 scooter listings (88 total)
- sources.json: source URLs, snapshot date, and data notes

INSTALL
1. Extract this ZIP to a normal folder.
2. In Google Chrome, open chrome://extensions.
3. Enable Developer mode.
4. Choose Load unpacked and select the extracted ev-comparison-assistant folder.
5. Open the extension. Use the car/scooter tabs, search, sorting, save shortlist, and select up to three vehicles for side-by-side comparison.

DETAILED COMPARISON
https://allaboutevs.com/compare-ev

DATA SOURCES
Electric cars: https://allaboutevs.com/electric-vehicle
Electric scooters: https://allaboutevs.com/two-wheeler/scooter
Two-wheeler catalogue: https://allaboutevs.com/two-wheeler/

DATA QUALITY AND LIMITATIONS
Snapshot prepared 9 October 2026 from the AllAboutEVs catalogue search/indexed content. This is a packaged snapshot, not a live API and it will not automatically update when the site changes. Some catalogue records contain broad model ranges, upcoming listings, ambiguous figures, or values that can vary by variant; status labels identify some of these cases. Some catalogue fields may be incomplete or inconsistent; these are labelled rather than silently treated as verified exact-variant data. Do not use catalogue-level values as a substitute for the exact variant's specification. Open the source catalogue and the AllAboutEVs comparison tool to verify current variant-specific data before purchase.

The extension only needs Chrome's storage permission to save the user's shortlist. It does not scrape the website in the background or send shortlist data to an external server.
